function onGameLoad(gameId)
	loadTerrain(gameId);
	loadSkyDome("Examples/CloudySky");
end

function onGameUnload(gameId)
	unloadSkyDome("Examples/CloudySky");
	unloadTerrain();
end

