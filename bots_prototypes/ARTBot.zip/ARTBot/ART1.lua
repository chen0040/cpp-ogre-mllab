local ART={};
ART.__index=ART;

function ART.create()
	local engine={};
	setmetatable(engine, ART);
	engine.rules=nil;
	
	return engine;
end

return ART;