local Bot={};

Bot.actions={};
Bot.actions[GameAgentAction.ATTACK]=1;
Bot.actions[GameAgentAction.IDLE]=2;
Bot.actions[GameAgentAction.APPROACH]=3;
Bot.actions[GameAgentAction.WANDER]=4;
Bot.actions[GameAgentAction.ESCAPE]=5;

Bot.err_threshold=0.01;
Bot.max_epoches=1000;
Bot.randomization_frequency=100;
Bot.training_error=100000;

function Bot.initialize(agent)
	--agent:addEnemy("PreyBot");
	--agent:addEnemy("PredatorBot");
	agent:setWalkSpeed(40);
	agent:setSenseRange(250);
	agent:setLife(300);
	
	local agentId=agent:getAgentId();
	
	Bot[agentId]={};
	Bot[agentId].brain=Bot.createMLP(agent:getScriptClassPath());
end

function Bot.createMLP(scriptClassPath)
	local brain={};	
	
	local MLPFactory=dofile(scriptClassPath .. "\\MLP.lua");
	local brain=MLPFactory.create(0.2);
	brain:addLayer(9); --input layer
	brain:addLayer(19); 
	brain:addLayer(5); --output layer	

	if fileExists(scriptClassPath .. "\\Saved.lua") then
		brain:load(scriptClassPath .. "\\Saved.lua");
	end
	
	return brain;
end

function Bot.getInput(entity)
	local inputs={};
	
	inputs[1]=entity:getSightedAttackerCount();
	inputs[2]=entity:getSightedTargetCount();
	inputs[3]=entity:getSightedAllyCount();
	inputs[4]=entity:getLife();
	inputs[5]=entity:getGun():getBulletCount();
	
	if entity:getCurrentTarget() == nil then
		inputs[6]=0;
		inputs[7]=0;
		inputs[8]=0;
		inputs[9]=0;
	else
		inputs[7]=0;
		inputs[8]=0;
		inputs[9]=0;
		
		inputs[6]=entity:getCurrentTarget():getLife();
		if entity:getCurrentTarget():isAttacking(entity) then
			inputs[7]=1;
		else
			inputs[7]=0;
		end
		if entity:isAttackable(entity:getCurrentTarget()) then
			inputs[8]=1;
		else
			inputs[8]=0;
		end
		inputs[9]=entity:getCurrentTarget():getGun():getBulletCount();	
	end
	
	return inputs;
end

function Bot.getOutput(entity)
	local outputs={};
	
	for i=1, 5 do
		if Bot.actions[entity:getCurrentAction()] == i then
			outputs[i]=1;
		else
			outputs[i]=0;
		end
	end
	
	return outputs;
end

function Bot.train(agent)
	local agentId=agent:getAgentId();
	local records=dofile(agent:getScriptClassPath() .. "\\data.lua");
	
	local brain=Bot[agentId].brain;
	local err=0;
	
	showConsole(true);
	
	local epoch=1;
	
	local minError=10000000000;
	for iter = 1, Bot.max_epoches do
		err=0;
		for recordIndex = 1, (# records) do
			local inputs=Bot.getInput(records[recordIndex]);
			local outputs=Bot.getOutput(records[recordIndex]);		
		
			brain:forwardProp(inputs);
			brain:backwardProp(outputs);
			err=err + brain:getMSE(outputs);
		end
		epoch=epoch + 1;
		print2Console("> epoch: " .. epoch .. " error: " .. err);
		repaint();
		if minError > err then
			minError = err;
			brain:saveWeights();
		end
		
		if iter % Bot.randomization_frequency == 0 then
			brain:randomizeWeights();
		end
	end
	
	brain:loadWeights();
	
	showConsole(false);
	brain:save(agent:getScriptClassPath() .. "\\Saved.lua");
	
	Bot.training_error=err;
	alert("Training Completed with errors " .. err, "Training Completed");
end

function Bot.think(agent)
	local agentId=agent:getAgentId();
	local brain=Bot[agentId].brain;
	--apply inputs to the neural network
	
	local inputs=Bot.getInput(agent);
	
	--compute outputs using neural network
	local outputs=brain:forwardProp(inputs);
	
	--convert neural network output into bot action
	local firingIndex=-1;
	local firingDegree=-100000;
	for i=1, 5 do
		if outputs[i] > firingDegree then
			firingIndex=i;
			firingDegree=outputs[i];
		end
	end
	
	if Bot.actions[GameAgentAction.ATTACK] == firingIndex then
		agent:attack();
	elseif Bot.actions[GameAgentAction.APPROACH] == firingIndex then
		agent:approach();
	elseif Bot.actions[GameAgentAction.ESCAPE] == firingIndex then
		agent:escape();
	elseif Bot.actions[GameAgentAction.WANDER] == firingIndex then
		agent:wander();
	elseif Bot.actions[GameAgentAction.IDLE] == firingIndex then
		agent:idle();
	end
end

function Bot.uploadConfig(agent)
	local agentId=agent:getAgentId();
	local brain=Bot[agentId].brain;
	local hiddenLayers=brain:getLayerCount() - 2;
	
	httpAddField("HiddenLayers", "" .. hiddenLayers);
	httpAddField("learningRate", "" .. (brain.learningRate));
	httpAddField("trainingError", "" .. (Bot.training_error));
	if hiddenLayers > 0 then
		for i=1, hiddenLayers do
			httpAddField("neuronCountInHiddenLayer" .. i, "" .. brain.network[i+1].neuronCount);
		end
	end
end

return Bot;
