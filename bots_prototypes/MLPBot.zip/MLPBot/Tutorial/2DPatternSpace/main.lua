dofile("GameLogger.lua");
dofile("GameUtil.lua");

--artificial neural network initialization
local MLPFactory=dofile(getDefaultScriptPath() .. "\\MLP.lua");
local ann=MLPFactory.create(0.2);
ann:addLayer(2);
ann:addLayer(5);
ann:addLayer(1);

--XOR logic gate initialization
local XORFactory=dofile(getDefaultScriptPath() .. "\\XOR.lua");
local xor=XORFactory.create();

--training phase with 1000 epoches
local minError=100000000000;
for epoch=1, 1000 do
	local err=0;
	for i=1, 4 do
		ann:forwardProp(xor:getPattern(i).inputs);
		ann:backwardProp(xor:getPattern(i).outputs);
		err=err + ann:getMSE(xor:getPattern(i).outputs);
	end
	if err < minError then
		minError=err;
		ann:saveWeights();
	end
	print2Console("err: " .. err);
end
ann:loadWeights();

--testing phase 
local accuracy=0;
for i=1, 4 do
	local predicted_outputs=ann:forwardProp(xor:getPattern(i).inputs);
	if predicted_outputs[1] > 0.5 then
		predicted_outputs[1]=1;
	else
		predicted_outputs[1]=0;
	end
	if predicted_outputs[1] == xor:getPattern(i).outputs[1] then
		accuracy=accuracy+1;
	end
end

accuracy = accuracy * 100 / 4;
print2Console("accuracy: " .. accuracy .. "%");



