dofile("GameUtil.lua");
dofile("GameWorld.lua");
GameAgentFactory=dofile("GameAgent.lua");

--train to obtain Saved.lua file;
local agnt=GameAgentFactory.create("expert agent");
initializeAgent(agnt);
processAgent(agnt);




