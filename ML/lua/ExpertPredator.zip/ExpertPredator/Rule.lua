local Rule={};
Rule.__index=Rule;

function Rule.create(scriptClassPath)
	local rule={};
	setmetatable(rule, Rule);
	rule.antes=nil;
	rule.conseqent=nil;
	rule.scriptClassPath=scriptClassPath;
	return rule;
end

function Rule:addAntecedent(subject, operator, object)
	local statementFactory=dofile(self.scriptClassPath .. "\\Statement.lua");
	local statement=statementFactory.create(subject, operator, object);
	
	if self.antes == nil then
		self.antes={};
		self.antes[1]=statement;
	else
		self.antes[(# self.antes)+1]=statement;
	end
end

function Rule:getAntecedentCount()
	if self.antes == nil then
		return 0;
	else
		return (# self.antes);
	end
end

function Rule:getAntecedent(index)
	if self.antes == nil then
		return nil;
	else
		return self.antes[index];
	end
end

function Rule:setConsequent(subject, operator, object)
	local statementFactory=dofile(self.scriptClassPath .. "\\Statement.lua");
	local statement=statementFactory.create(subject, operator, object);
	
	self.consequent=statement;
end

function Rule:getConsequent()
	return self.consequent;
end

function Rule:toString()
	local msg="If ";
	
	local conditionCount=self:getAntecedentCount();
	
	if conditionCount > 1 then
		for i=1, conditionCount do
			if i > 1 then
				msg = msg .. " and " .. self.antes[i]:toString();
			else
				msg=msg .. self.antes[i]:toString();
			end
		end
	else
		msg=msg .. self.antes[1]:toString();
	end
	
	msg = msg .. " then ";
	msg = msg .. self.consequent:toString();
	
	return msg;
end

return Rule;
