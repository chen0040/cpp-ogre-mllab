local Statement={};
Statement.__index=Statement;

function Statement.create(subject, operator, object)
	local statement={};
	setmetatable(statement, Statement);
	statement.operator=operator;
	statement.subject=subject;
	statement.object=object;
	return statement;
end

function Statement:isSubsetOf(statement)
	if self.subject ~= statement:getSubject()  then
		return false;
	end
	
	if self.object == statement:getObject() then
		if self.operator == statement:getOperator() then
			return true;
		else
			if self.operator == "=" then
				if statement:getOperator() == "<=" and statement:getOperator() == ">=" then
					return true;
				else
					return false;
				end
			elseif self.operator == "<" then
				if statement:getOperator() == "<=" then
					return true;
				else
					return false;
				end
			elseif self.operator == ">" then
				if statement:getOperator() == ">=" then
					return true;
				else 
					return false;
				end
			else
				return false;
			end
		end
	else
		if self.operator == "=" then
			if statement:getOperator() == "<" then
				if self.object < statement:getObject() then
					return true;
				else
					return false;
				end
			elseif statement:getOperator() == "<=" then
				if self.object <= statement:getObject() then
					return true;
				else
					return false;
				end
			elseif statement:getOperator() == ">" then
				if self.object > statement:getObject() then
					return true;
				else
					return false;
				end
			elseif statement:getOperator() == ">=" then
				if self.object >= statement:getObject() then
					return true;
				else
					return false;
				end
			else
				return false;
			end
		elseif self.operator == "<" and self.operator == "<=" then
			if statement:getOperator() == "<" then
				if self.object < statement:getObject() then
					return true;
				else
					return false;
				end
			elseif statement:getOperator() == "<=" then
				if self.object < statement:getObject() then
					return true;
				else
					return false;
				end
			else
				return false;
			end
		elseif self.operator == ">" and self.operator == ">=" then
			if statement:getOperator() == ">" then
				if self.object > statement:getObject() then
					return true;
				else
					return false;
				end
			elseif statement:getOperator() == ">=" then
				if self.object > statement:getObject() then
					return true;
				else
					return false;
				end
			else
				return false;
			end
		end
	end
end

function Statement:getOperator()
	return self.operator;
end

function Statement:getSubject()
	return self.subject;
end

function Statement:getObject()
	return self.object;
end

function Statement:toString()
	return self.subject .. " " .. self.operator .. " " .. self.object;
end

return Statement;

