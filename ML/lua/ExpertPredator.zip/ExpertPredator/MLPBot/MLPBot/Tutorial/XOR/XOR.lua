local XOR={};
XOR.__index=XOR;

function XOR.create()
	local gate={};
	setmetatable(gate, XOR);
	
	gate.patterns={};
	gate.patterns[1]=gate:createRecord(0, 0, 0);
	gate.patterns[2]=gate:createRecord(0, 1, 1);
	gate.patterns[3]=gate:createRecord(1, 0, 1);
	gate.patterns[4]=gate:createRecord(1, 1, 0);
	
	return gate;
end

function XOR:createRecord(in1, in2, out)
	local record={};
	record.inputs={};
	record.inputs[1]=in1;
	record.inputs[2]=in2;
	record.outputs={};
	record.outputs[1]=out;
	return record;
end

function XOR:getPatternCount()
	return (# self.patterns);
end

function XOR:getPattern(index)
	return self.patterns[index];
end

return XOR;
