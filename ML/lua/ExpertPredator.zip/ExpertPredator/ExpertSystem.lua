local ExpertSystem={};
ExpertSystem.__index=ExpertSystem;

function ExpertSystem.create(scriptClassPath)
	local engine={};
	setmetatable(engine, ExpertSystem);
	engine.rules=nil;
	
	local WorkingMemoryFactory=dofile(scriptClassPath .. "\\WorkingMemory.lua");
	engine.workingMemory=WorkingMemoryFactory.create(scriptClassPath);
	engine.scriptClassPath=scriptClassPath;
	
	return engine;
end

function ExpertSystem:addRule(rule)
	if self.rules==nil then
		self.rules={};
		self.rules[1]=rule;
	else
		self.rules[(# self.rules)+1]=rule;
	end
end

function ExpertSystem:getRuleCount()
	if self.rules==nil then
		return 0;
	else
		return (# self.rules);
	end
end

function ExpertSystem:backwardChain(goal)

	print2Console("Working Memory:\n" .. self.workingMemory:toString() .. "\n");
	
	local ruleCount=self:getRuleCount();
	
	if ruleCount == 0 then
		return nil;
	end
	
	local matchedRule=nil;
	for i = 1, ruleCount do
		if self.rules[i]:getConsequent():getSubject() == goal then
			if self:matchRule(self.rules[i]) then
				matchedRule=self.rules[i];
				self.workingMemory:addFact(matchedRule:getConsequent());
				break;
			end
		end
	end
	
	print2Console("\nWorking Memory:\n" .. self.workingMemory:toString() .. "\n");
	
	if matchedRule == nil then
		return nil;
	else
		return matchedRule:getConsequent();
	end
end

function ExpertSystem:matchRule(rule)
	local conditionCount=rule:getAntecedentCount();
	local matched=true;
	for i = 1, conditionCount do
		if self:matchFact(rule:getAntecedent(i)) == false then
			matched=false;
			break;
		end
	end
	
	if matched then
		print2Console("Rule Matched: " .. rule:toString());
	end
	
	return matched;
end

function ExpertSystem:matchFact(fact)
	if self.workingMemory:match(fact) then
		print2Console("Working Memory Matched: " .. fact:toString());
		return true;
	end
	
	local ruleCount=self:getRuleCount();
	
	if ruleCount == 0 then
		return false;
	end
	
	local matchedRule=nil;
	for i = 1, ruleCount do
		if fact:isSubsetOf(self.rules[i]:getConsequent()) then
			if self:matchRule(self.rules[i]) then
				matchedRule=self.rules[i];
				self.workingMemory:addFact(fact);
				break;
			end
		end
	end
	
	if matchedRule == nil then
		return false;
	else
		return true;
	end	
	
end

function ExpertSystem:clearMemory()
	self.workingMemory:clear();
end

function ExpertSystem:addFact(subject, operator, object)
	local factFactory=dofile(self.scriptClassPath .. "\\Statement.lua");
	local fact=factFactory.create(subject, operator, object);
	self.workingMemory:addFact(fact);
end

return ExpertSystem;