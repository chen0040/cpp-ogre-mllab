local Bot={};

function Bot.initialize(agent)
	local agentId=agent:getAgentId();
	Bot[agentId]={};
	Bot[agentId].agent=agent;
	--attack any type of bots
	
	agent:setLife(100);
	agent:setSenseRange(200);
	agent:setWalkSpeed(30);
	
	Bot[agentId].brain=Bot.createExpertSystem(agent:getScriptClassPath());
end

function Bot.createExpertSystem(scriptClassPath)
	local ExpertSystemFactory=dofile(scriptClassPath .. "\\ExpertSystem.lua");
	local brain=ExpertSystemFactory.create(scriptClassPath);
	
	local ruleFactory=dofile(scriptClassPath .. "\\Rule.lua");
	
	local rule=nil;
	
	rule=ruleFactory.create(scriptClassPath);
	rule:addAntecedent("targetExists", "=", true);
	rule:setConsequent("action", "=", GameAgentAction.IDLE);
	brain:addRule(rule);
	
	rule=ruleFactory.create(scriptClassPath);
	rule:addAntecedent("targetExists", "=", true);
	rule:addAntecedent("targetTooFar", "=", true);
	rule:setConsequent("action", "=", GameAgentAction.APPROACH);
	brain:addRule(rule);
	
	rule=ruleFactory.create(scriptClassPath);
	rule:addAntecedent("targetExists", "=", true);
	rule:setConsequent("action", "=", GameAgentAction.ATTACK);
	brain:addRule(rule);
	
	rule=ruleFactory.create(scriptClassPath);
	rule:addAntecedent("targetExists", "=", true);
	rule:addAntecedent("distance", ">", 120);
	rule:setConsequent("targetTooFar", "=", true);
	brain:addRule(rule);
	
	rule=ruleFactory.create(scriptClassPath);
	rule:addAntecedent("targetExists", "=", true);
	rule:addAntecedent("distance", ">", 70);
	rule:addAntecedent("currentAction", "=", GameAgentAction.APPROACH);
	rule:setConsequent("targetTooFar", "=", true);
	brain:addRule(rule);
	
	rule=ruleFactory.create(scriptClassPath);
	rule:addAntecedent("targetExists", "=", true);
	rule:addAntecedent("distance", "<=", 120);
	rule:setConsequent("targetTooFar", "=", true);
	brain:addRule(rule);
	
	rule=ruleFactory.create(scriptClassPath);
	rule:addAntecedent("targetExists", "=", true);
	rule:addAntecedent("distance", "<=", 70);
	rule:setConsequent("targetTooFar", "=", false);
	brain:addRule(rule);
	
	
	return brain;
end

function Bot.infer(agent)
	local agentId=agent:getAgentId();
	local brain=Bot[agentId].brain;
	
	brain:clearMemory();
	brain:addFact("currentAction", "=", agent:getCurrentAction());
	
	local target=agent:getCurrentTarget();
	if target == nil then
		brain:addFact("targetExists", "=", false);
	else
		brain:addFact("targetExists", "=", true);
		local distance=agent:getDistance(target);
		brain:addFact("distance", "=", distance);
	end
	
	return brain:backwardChain("action");
end

function Bot.think(agent)
	local agentId=agent:getAgentId();	
	local resultantAction=Bot.infer(agent);
	
	local action=resultantAction:getObject();
	
	if action == GameAgentAction.ATTACK then
		agent:attack();
	elseif action == GameAgentAction.IDLE then
		agent:idle();
	elseif action == GameAgentAction.APPROACH then
		agent:approach();
	elseif action == GameAgentAction.WANDER then
		agent:wander();
	elseif action == GameAgentAction.ESCAPE then
		agent:escape();
	else
		agent:slump();
	end
end

function Bot.train(agent)
	alert("Training not supported", "This bot does not have training algorithm embeded in it");
end

function Bot.uploadConfig(agent)
	alert("Method not implemented", "Method not implemented");
end

return Bot;

