local WorkingMemory={};
WorkingMemory.__index=WorkingMemory;

function WorkingMemory.create(scriptClassPath)
	local memory={};
	setmetatable(memory, WorkingMemory);
	memory.facts=nil;
	memory.scriptClassPath=scriptClassPath;
	return memory;
end

function WorkingMemory:addFact(statement)
	local statementCount=self:getFactCount();
	local addStatement=true;
	if statementCount == 0 then
		addStatement=true;
	else
		for i=1, statementCount do
			if self.facts[i]:isSubsetOf(statement) then
				self.facts[i]=statement;
				addStatement=false;
			end
		end
	end
	
	if addStatement == true then
		if self.facts == nil then
			self.facts = {};
			self.facts[1]=statement;
		else
			self.facts[(# self.facts) + 1]=statement;
		end
	end
end

function WorkingMemory:getFactCount()
	if self.facts == nil then
		return 0;
	else
		return (# self.facts);
	end
end

function WorkingMemory:clear()
	self.facts=nil;
end

function WorkingMemory:match(statement)
	local statementCount=self:getFactCount();
	local matched=false;
	if statementCount ~= 0 then
		for i=1, statementCount do
			if self.facts[i]:isSubsetOf(statement) then
				matched=true;
				break;
			end
		end	
	end
	
	return matched;
end

function WorkingMemory:toString()
	local msg="";
	local factCount=self:getFactCount();
	for i=1, factCount do
		if i == 1 then
			msg = msg .. "Fact " .. i .. ": " .. self.facts[i]:toString();
		else
			msg = msg .. "\nFact " .. i .. ": " .. self.facts[i]:toString();
		end
	end
	return msg;
end

return WorkingMemory;